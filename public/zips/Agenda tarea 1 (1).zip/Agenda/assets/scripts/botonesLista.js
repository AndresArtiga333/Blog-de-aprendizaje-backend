const botonA = document.getElementById("botonA");
const botonF = document.getElementById("botonF");
const botonL = document.getElementById("botonL");

botonA.addEventListener('click', () =>{
    window.location.href = "../pages/agregarContacto.html"
})

botonF.addEventListener('click', () =>{
    window.location.href= "../pages/favoritos.html"
})

botonL.addEventListener('click', () =>{
    window.location.href="../pages/listaDeTareas.html"
})