const botonRegresar = document.getElementById("botonRegresar")

botonRegresar.addEventListener(('click'), () =>{
    window.location.href ="../pages/contactos.html"
})